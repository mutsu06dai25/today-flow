package jp.todayflow

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.widget.RemoteViews
import java.util.Locale

/**
 * ホーム画面ウィジェット：「いまここ」と次の1件を、アプリと同じ〇と線で表示する。
 * ノードや進捗バーはウィジェットでは自由に描けないため、画像にして貼り付ける。
 */
class FlowWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, build(c)) }
    }

    override fun onReceive(c: Context, intent: Intent) {
        super.onReceive(c, intent)
        if (intent.action == ACTION_DONE) {
            val steps = Store.load(c)
            val idx = steps.indexOfFirst { !it.done }
            if (idx >= 0) {
                steps[idx].done = true
                Store.save(c, steps)
            }
        }
    }

    companion object {
        const val ACTION_DONE = "jp.todayflow.ACTION_DONE"

        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, FlowWidget::class.java))
            ids.forEach { m.updateAppWidget(it, build(c)) }
        }

        /** ノード＋横線の画像。高さは隣の文字の1行目に合わせる。 */
        private fun nodeBitmap(c: Context, t: FlowTheme, s: NodeState, hDp: Float, small: Boolean): Bitmap {
            val d = c.resources.displayMetrics.density
            val w = (37 * d).toInt()
            val h = (hDp * d).toInt()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val cy = h / 2f
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1 * d
            p.color = if (s == NodeState.NOW) t.accent else t.hair
            cv.drawLine(15 * d, cy, w.toFloat(), cy, p)
            Art.node(cv, t, s, 7.5f * d, cy, d, 0.25f, if (small) 0.75f else 1f, t.bgBottom, p)
            return bmp
        }

        private fun ticksBitmap(c: Context, t: FlowTheme, flags: BooleanArray, cur: Int): Bitmap {
            val d = c.resources.displayMetrics.density
            val w = (300 * d).toInt()
            val h = (t.tickH * d).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Art.ticks(Canvas(bmp), t, w.toFloat(), h.toFloat(), flags, cur, false, d, Paint(Paint.ANTI_ALIAS_FLAG))
            return bmp
        }

        private fun build(c: Context): RemoteViews {
            val t = Themes.current(c)
            val tactical = t.look == Look.TACTICAL
            val steps = Store.load(c)
            val v = RemoteViews(c.packageName, R.layout.widget)
            val done = steps.count { it.done }
            val idx = steps.indexOfFirst { !it.done }

            v.setInt(R.id.w_root, "setBackgroundResource", t.widgetBg)
            v.setTextViewText(R.id.w_title, t.titlePrefix + "今日の流れ")
            v.setTextColor(R.id.w_title, if (tactical) t.ink else t.muted)
            v.setTextViewText(
                R.id.w_count,
                if (steps.isEmpty()) "" else if (tactical)
                    String.format(Locale.US, "%02d/%02d", done, steps.size) else "$done / ${steps.size}"
            )
            v.setTextColor(R.id.w_count, t.muted)

            if (tactical && steps.isNotEmpty()) {
                v.setViewVisibility(R.id.w_ticks, View.VISIBLE)
                v.setImageViewBitmap(R.id.w_ticks, ticksBitmap(c, t, BooleanArray(steps.size) { steps[it].done }, idx))
            } else v.setViewVisibility(R.id.w_ticks, View.GONE)

            v.setTextColor(R.id.w_place, t.tag)
            v.setTextColor(R.id.w_what, t.ink)
            v.setTextColor(R.id.w_next, t.muted)

            if (idx < 0) {
                v.setViewVisibility(R.id.w_place, View.GONE)
                v.setViewVisibility(R.id.w_node, View.GONE)
                v.setViewVisibility(R.id.w_nextrow, View.GONE)
                v.setViewVisibility(R.id.w_done, View.GONE)
                v.setTextViewText(R.id.w_what, if (steps.isEmpty()) "タップして今日の流れを作る" else "すべて完了")
            } else {
                val now = steps[idx]
                v.setViewVisibility(R.id.w_place, View.VISIBLE)
                v.setTextViewText(
                    R.id.w_place,
                    if (tactical) String.format(Locale.US, "WP.%02d　", idx + 1) + now.place else now.place
                )
                v.setViewVisibility(R.id.w_node, View.VISIBLE)
                v.setImageViewBitmap(R.id.w_node, nodeBitmap(c, t, NodeState.NOW, 26f, false))
                v.setTextViewText(R.id.w_what, now.what)

                val next = steps.getOrNull(idx + 1)
                if (next != null) {
                    v.setViewVisibility(R.id.w_nextrow, View.VISIBLE)
                    v.setImageViewBitmap(R.id.w_nnode, nodeBitmap(c, t, NodeState.TODO, 19f, true))
                    v.setTextViewText(R.id.w_next, next.what)
                } else v.setViewVisibility(R.id.w_nextrow, View.GONE)

                v.setViewVisibility(R.id.w_done, View.VISIBLE)
                v.setInt(R.id.w_done, "setBackgroundResource", t.widgetBtn)
                v.setTextColor(R.id.w_done, t.widgetBtnText)
                v.setTextViewText(R.id.w_done, if (tactical) "DONE" else "完了")
            }

            val open = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_root, open)
            val donePi = PendingIntent.getBroadcast(
                c, 1, Intent(c, FlowWidget::class.java).setAction(ACTION_DONE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_done, donePi)
            return v
        }
    }
}
