package jp.todayflow

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.cos

enum class NodeState { TODO, NOW, DONE }

/** ノードと進捗バーの描き方。アプリ画面とウィジェット（画像化）で共通に使う。 */
object Art {

    /**
     * ノードを描く。
     * MINIMAL：輪郭の〇／二重丸（外側が呼吸する）／小さな黒丸
     * TACTICAL：照準（〇＋十字、いまの手順は回転）／小さな塗り丸
     * phase は 0〜1 のアニメーション位置。
     */
    fun node(
        c: Canvas, t: FlowTheme, s: NodeState, cx: Float, cy: Float, d: Float,
        phase: Float, scale: Float, fill: Int, p: Paint,
    ) {
        val r = 6.5f * d
        c.save()
        c.scale(scale, scale, cx, cy)
        p.shader = null
        p.strokeCap = Paint.Cap.BUTT
        if (t.look == Look.MINIMAL) {
            when (s) {
                NodeState.DONE -> {
                    p.style = Paint.Style.FILL; p.color = t.lineDone
                    c.drawCircle(cx, cy, r * 0.62f, p)
                }
                NodeState.NOW -> {
                    val k = ((1 - cos(phase * 2 * PI)) / 2).toFloat() // 0→1→0
                    p.style = Paint.Style.STROKE; p.strokeWidth = 1 * d
                    p.color = t.accent; p.alpha = (k * 0.3f * 255).toInt()
                    c.drawCircle(cx, cy, (r + 6 * d) * (0.7f + 0.3f * k), p)
                    p.style = Paint.Style.FILL; p.color = fill
                    c.drawCircle(cx, cy, r, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = t.accent
                    c.drawCircle(cx, cy, r - 0.75f * d, p)
                    p.style = Paint.Style.FILL
                    c.drawCircle(cx, cy, 2.6f * d, p)
                }
                NodeState.TODO -> {
                    p.style = Paint.Style.FILL; p.color = fill
                    c.drawCircle(cx, cy, r, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = 1 * d; p.color = t.muted
                    c.drawCircle(cx, cy, r - 0.5f * d, p)
                }
            }
        } else {
            if (s == NodeState.DONE) {
                p.style = Paint.Style.FILL; p.color = t.lineDone
                c.drawCircle(cx, cy, r * 0.55f, p)
            } else {
                val col = if (s == NodeState.NOW) t.accent else t.muted
                if (s == NodeState.NOW) c.rotate(phase * 360f, cx, cy)
                p.style = Paint.Style.FILL; p.color = fill
                c.drawCircle(cx, cy, r, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 1 * d; p.color = col
                c.drawCircle(cx, cy, r - 0.5f * d, p)
                val e = r + 4 * d
                c.drawLine(cx, cy - e, cx, cy + e, p)
                c.drawLine(cx - e, cy, cx + e, cy, p)
            }
        }
        c.restore()
    }

    /** 区切り型の進捗バー。完了は塗り、いまの手順は別色（blinkOff のときは薄く）。 */
    fun ticks(
        c: Canvas, t: FlowTheme, w: Float, h: Float, done: BooleanArray, cur: Int,
        blinkOff: Boolean, d: Float, p: Paint,
    ) {
        if (done.isEmpty()) return
        val gap = 3 * d
        val seg = (w - gap * (done.size - 1)) / done.size
        val rr = if (t.tickH >= 4f) 1 * d else 0f
        val rect = RectF()
        p.style = Paint.Style.FILL
        p.shader = null
        for (i in done.indices) {
            p.color = when {
                done[i] -> t.tickOn
                i == cur -> t.tickCur
                else -> t.hair
            }
            if (i == cur && blinkOff) p.alpha = 90
            val x = i * (seg + gap)
            rect.set(x, 0f, x + seg, h)
            c.drawRoundRect(rect, rr, rr, p)
        }
    }
}
