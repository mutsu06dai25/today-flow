package jp.todayflow

import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import java.util.Calendar
import java.util.Collections
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: View
    private lateinit var list: LinearLayout
    private lateinit var meta: TextView
    private lateinit var count: TextView
    private lateinit var themeBtn: TextView
    private lateinit var ticks: TicksView
    private lateinit var title: TextView
    private lateinit var empty: TextView
    private lateinit var addLine: View
    private lateinit var inPlace: EditText
    private lateinit var inWhat: EditText
    private lateinit var addBtn: TextView
    private lateinit var reset: TextView

    private var steps = mutableListOf<Step>()
    private var theme = Themes.MINIMAL

    private var entryAnim = true
    private var justCompleted = -1
    private var justAdded = -1
    private val d by lazy { resources.displayMetrics.density }

    private val chakra by lazy { resources.getFont(R.font.chakra_medium) }
    private val chakraBold by lazy { resources.getFont(R.font.chakra_semibold) }
    private val dmLight by lazy { resources.getFont(R.font.dmmono_light) }
    private val dmMono by lazy { resources.getFont(R.font.dmmono_regular) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)
        list = findViewById(R.id.list)
        meta = findViewById(R.id.h_meta)
        count = findViewById(R.id.h_count)
        themeBtn = findViewById(R.id.h_theme)
        ticks = findViewById(R.id.h_ticks)
        title = findViewById(R.id.h_title)
        empty = findViewById(R.id.empty)
        addLine = findViewById(R.id.add_line)
        inPlace = findViewById(R.id.in_place)
        inWhat = findViewById(R.id.in_what)
        addBtn = findViewById(R.id.add_btn)
        reset = findViewById(R.id.reset)

        addBtn.setOnClickListener { add() }
        inWhat.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { add(); true } else false
        }
        themeBtn.setOnClickListener {
            theme = Themes.next(this)
            applyTheme()
            entryAnim = true
            render()
            FlowWidget.updateAll(this)
        }
        reset.setOnClickListener {
            dialog()
                .setMessage("今日の流れを全部消しますか？")
                .setPositiveButton("消す") { _, _ -> steps.clear(); commit() }
                .setNegativeButton("やめる", null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        steps = Store.load(this)
        theme = Themes.current(this)
        applyTheme()
        entryAnim = true
        render()
    }

    private fun dialog() = AlertDialog.Builder(
        this,
        if (theme.light) android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
        else android.R.style.Theme_DeviceDefault_Dialog_Alert
    )

    // ───────── テーマの適用（背景・ヘッダー・追加欄） ─────────
    @Suppress("DEPRECATION")
    private fun applyTheme() {
        val t = theme
        root.background = BgDrawable(t, d)
        window.statusBarColor = t.bgTop
        window.navigationBarColor = t.bgBottom
        var flags = window.decorView.systemUiVisibility and
            (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR).inv()
        if (t.light) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = flags

        val tactical = t.look == Look.TACTICAL
        meta.typeface = if (tactical) chakra else dmLight
        meta.textSize = if (tactical) 10.5f else 12f
        meta.setTextColor(t.muted)
        count.typeface = if (tactical) chakra else dmMono
        count.textSize = if (tactical) 22f else 12f
        count.setTextColor(t.muted)

        themeBtn.text = t.label
        themeBtn.typeface = if (tactical) chakra else dmMono
        themeBtn.setTextColor(t.muted)
        themeBtn.background = GradientDrawable().apply {
            setStroke((1 * d).toInt(), t.hair)
            cornerRadius = if (tactical) 2 * d else 20 * d
        }

        ticks.visibility = if (tactical) View.VISIBLE else View.GONE
        ticks.layoutParams = ticks.layoutParams.apply { height = (t.tickH * d).toInt().coerceAtLeast(1) }

        title.typeface = if (tactical) chakraBold else Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.textSize = if (tactical) 11f else 13f
        title.letterSpacing = if (tactical) 0.32f else 0.3f
        title.setTextColor(t.ink)
        title.text = if (t.titlePrefix.isEmpty()) "今日の流れ" else SpannableStringBuilder().apply {
            append(t.titlePrefix, ForegroundColorSpan(t.accent), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            append("今日の流れ")
        }

        empty.setTextColor(t.muted)
        addLine.setBackgroundColor(t.hair)
        for (e in listOf(inPlace, inWhat)) {
            e.setTextColor(t.ink)
            e.setHintTextColor(t.muted)
            e.typeface = if (tactical) chakra else Typeface.DEFAULT
        }
        inPlace.hint = if (tactical) "LOC" else "場所"
        inWhat.hint = if (tactical) "次の手順" else "次にやること"

        addBtn.background = GradientDrawable().apply {
            when (t.id) {
                Themes.WHITE_OPS.id -> { shape = GradientDrawable.OVAL; setColor(t.accent) }
                Themes.ARCTIC.id -> { setStroke((1 * d).toInt(), t.accent) }
                else -> { shape = GradientDrawable.OVAL; setStroke((1 * d).toInt(), t.muted) }
            }
        }
        addBtn.setTextColor(
            when (t.id) {
                Themes.WHITE_OPS.id -> 0xFFFFFFFF.toInt()
                Themes.ARCTIC.id -> t.accent
                else -> t.ink
            }
        )
        reset.typeface = if (tactical) chakra else dmMono
        reset.setTextColor(t.muted)
    }

    // ───────── 操作 ─────────
    private fun add() {
        val w = inWhat.text.toString().trim()
        if (w.isEmpty()) { inWhat.requestFocus(); return }
        // 場所は残す（同じ場所での作業が続くことが多いため）
        steps.add(Step(inPlace.text.toString().trim(), w, false))
        justAdded = steps.size - 1
        inWhat.setText("")
        commit()
    }

    private fun toggle(i: Int) {
        val s = steps[i]
        s.done = !s.done
        if (s.done) {
            justCompleted = i
            list.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        }
        commit()
    }

    private fun commit() {
        Store.save(this, steps)
        render()
    }

    // ───────── 描画 ─────────
    private fun render() {
        val t = theme
        val tactical = t.look == Look.TACTICAL
        list.removeAllViews()
        val nowIdx = steps.indexOfFirst { !it.done }
        val doneCount = steps.count { it.done }
        empty.visibility = if (steps.isEmpty()) View.VISIBLE else View.GONE
        val rails = ArrayList<RailView>()
        val rows = ArrayList<View>()

        steps.forEachIndexed { i, s ->
            val row = layoutInflater.inflate(R.layout.item_step, list, false)
            val rail = row.findViewById<RailView>(R.id.rail)
            val place = row.findViewById<TextView>(R.id.place)
            val what = row.findViewById<BracketTextView>(R.id.what)
            val isNow = i == nowIdx
            val isNext = nowIdx >= 0 && i == nowIdx + 1

            // 場所ラベル（TACTICALは経由地点の番号つき）
            place.typeface = if (tactical) chakra else Typeface.create("sans-serif-medium", Typeface.NORMAL)
            place.setTextColor(t.tag)
            place.text = if (tactical) SpannableStringBuilder().apply {
                append(String.format(Locale.US, "WP.%02d", i + 1), ForegroundColorSpan(t.muted), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                append("　")
                append(s.place)
            } else s.place
            // 場所が空でも高さは保つ（線の位置を揃えるため）
            if (place.text.isEmpty()) place.text = " "

            // 手順の文字：いまの手順だけ大きく太く、次は通常の色、それ以外は薄く
            what.text = s.what
            what.textSize = if (isNow) t.nowSize else t.whatSize
            what.typeface = if (isNow) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            what.setTextColor(if (isNow || isNext) t.ink else t.muted)
            what.paintFlags = if (s.done) what.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            else what.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            val lp = what.layoutParams as LinearLayout.LayoutParams
            if (isNow && t.bracketLen > 0f) {
                what.bracketColor = t.accent
                what.bracketLen = t.bracketLen * d
                what.bracketStroke = t.bracketStroke * d
                what.setPadding((10 * d).toInt(), (2 * d).toInt(), (10 * d).toInt(), (3 * d).toInt())
                lp.marginStart = (6 * d).toInt()
                lp.topMargin = (3 * d).toInt()
            } else {
                what.bracketLen = 0f
                what.setPadding(0, 0, 0, 0)
                lp.marginStart = 0
                lp.topMargin = (5 * d).toInt()
            }
            what.layoutParams = lp

            rail.theme = t
            rail.anchor = what
            rail.isFirst = i == 0
            rail.isLast = i == steps.size - 1
            rail.prevDone = i > 0 && steps[i - 1].done
            rail.done = s.done
            rail.now = isNow

            row.setOnClickListener { toggle(i) }
            row.setOnLongClickListener { showMenu(what, i); true }

            list.addView(row)
            rails.add(rail)
            rows.add(row)
        }

        // 起動・テーマ切り替え時の登場アニメーション
        rows.forEachIndexed { i, row ->
            if (entryAnim) {
                if (tactical) reveal(row, 80L * i) else rise(row, 70L * i, 8 * d)
            } else if (i == justAdded) {
                rise(row, 0, 10 * d)
            }
        }

        // 完了したとき：ノードが弾み、幹が次へ伸び、次の手順への横線が引かれる
        if (justCompleted in rails.indices) {
            val r = rails[justCompleted]
            tween(0.4f, 1f, 450, 0, OvershootInterpolator(3f)) { r.nodeScale = it }
            if (!r.isLast) {
                val next = rails[justCompleted + 1]
                tween(0f, 1f, 280, 60, DecelerateInterpolator()) { r.fillBottom = it }
                tween(0f, 1f, 220, 320, DecelerateInterpolator()) { next.fillTop = it }
                if (next.now) {
                    tween(0f, 1f, 380, 520, DecelerateInterpolator()) { next.branchGrow = it }
                    tween(0.5f, 1f, 420, 520, OvershootInterpolator(2.5f)) { next.nodeScale = it }
                }
            }
        }

        // ヘッダー
        val c = Calendar.getInstance()
        val wd = arrayOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT")[c.get(Calendar.DAY_OF_WEEK) - 1]
        val date = String.format(Locale.US, "%02d.%02d ", c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        meta.text = SpannableStringBuilder().apply {
            append(date)
            if (tactical) {
                append(wd, ForegroundColorSpan(t.ink), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                append("\n")
                append(if (nowIdx < 0) "STATUS / COMPLETE" else String.format(Locale.US, "NEXT / WP.%02d", nowIdx + 1))
            } else append(wd)
        }
        count.text = SpannableStringBuilder().apply {
            val dn = if (tactical) String.format(Locale.US, "%02d", doneCount) else "$doneCount"
            val tn = if (tactical) String.format(Locale.US, "%02d", steps.size) else "${steps.size}"
            append(dn, ForegroundColorSpan(t.ink), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            append(if (tactical) "/$tn" else " / $tn")
        }
        ticks.update(t, BooleanArray(steps.size) { steps[it].done }, nowIdx)

        entryAnim = false
        justCompleted = -1
        justAdded = -1
    }

    /** ミニマル：下からふわっと出る */
    private fun rise(v: View, delay: Long, dy: Float) {
        v.alpha = 0f
        v.translationY = dy
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(600)
            .setInterpolator(DecelerateInterpolator(2f)).start()
    }

    /** TACTICAL：左から右へスキャンするように現れる */
    private fun reveal(v: View, delay: Long) {
        v.alpha = 0f
        v.post {
            val w = v.width
            val h = v.height
            v.clipBounds = Rect(0, 0, 0, h)
            v.alpha = 1f
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 500
                startDelay = delay
                interpolator = DecelerateInterpolator(2f)
                addUpdateListener {
                    val f = it.animatedValue as Float
                    v.clipBounds = if (f >= 1f) null else Rect(0, 0, (w * f).toInt(), h)
                }
                start()
            }
        }
    }

    /** 値を from→to に動かす。開始前の値も from にしておく。 */
    private fun tween(
        from: Float, to: Float, dur: Long, delay: Long,
        interp: TimeInterpolator, set: (Float) -> Unit,
    ) {
        set(from)
        ValueAnimator.ofFloat(from, to).apply {
            duration = dur
            startDelay = delay
            interpolator = interp
            addUpdateListener { set(it.animatedValue as Float) }
            start()
        }
    }

    private fun showMenu(anchor: View, i: Int) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "編集")
        if (i > 0) pm.menu.add(0, 2, 1, "上へ移動")
        if (i < steps.size - 1) pm.menu.add(0, 3, 2, "下へ移動")
        pm.menu.add(0, 4, 3, "削除")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> edit(i)
                2 -> { Collections.swap(steps, i, i - 1); commit() }
                3 -> { Collections.swap(steps, i, i + 1); commit() }
                4 -> { steps.removeAt(i); commit() }
            }
            true
        }
        pm.show()
    }

    private fun edit(i: Int) {
        val s = steps[i]
        val pad = (20 * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val p = EditText(this).apply { hint = "場所"; setText(s.place); setSingleLine() }
        val w = EditText(this).apply { hint = "やること"; setText(s.what); setSingleLine() }
        box.addView(p)
        box.addView(w)
        dialog()
            .setTitle("編集")
            .setView(box)
            .setPositiveButton("保存") { _, _ ->
                val txt = w.text.toString().trim()
                if (txt.isNotEmpty()) {
                    s.place = p.text.toString().trim()
                    s.what = txt
                    commit()
                }
            }
            .setNegativeButton("やめる", null)
            .show()
    }
}
