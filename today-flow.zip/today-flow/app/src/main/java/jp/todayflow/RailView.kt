package jp.todayflow

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.TextView

/**
 * 手順の左側：縦の幹・ノード・手順の文字へ伸びる横線。
 * ノードと横線は「やること」の文字の1行目の中心に揃える（anchor の位置から計算）。
 */
class RailView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var theme: FlowTheme = Themes.MINIMAL
    var anchor: TextView? = null
    var isFirst = false
    var isLast = false
    var prevDone = false
    var done = false
    var now = false

    var fillTop = 1f
        set(v) { field = v; invalidate() }
    var fillBottom = 1f
        set(v) { field = v; invalidate() }
    var branchGrow = 1f
        set(v) { field = v; invalidate() }
    var nodeScale = 1f
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var anim: ValueAnimator? = null

    fun startLoop() {
        if (!now || !isAttachedToWindow || anim != null) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (theme.look == Look.MINIMAL) 2400 else 6000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startLoop()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    /** 文字の1行目の見た目の中心（この View の座標）。 */
    private fun nodeY(): Float {
        val a = anchor ?: return 20 * d
        val col = a.parent as? View ?: return 20 * d
        val l = a.layout ?: return col.top + a.top + a.height / 2f - top
        val fm = a.paint.fontMetrics
        val mid = l.getLineBaseline(0) + (fm.ascent + fm.descent) / 2f
        return col.top + a.top + a.totalPaddingTop + mid - top
    }

    override fun onDraw(canvas: Canvas) {
        val cx = 7.5f * d
        val ny = nodeY()
        val r = 6.5f * d
        val gap = 3 * d
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1 * d
        p.strokeCap = Paint.Cap.BUTT
        p.shader = null

        // 幹（ノードの上と下で色を分ける）
        if (!isFirst) {
            val y1 = ny - r - gap
            p.color = theme.hair
            canvas.drawLine(cx, 0f, cx, y1, p)
            if (prevDone) {
                p.color = theme.lineDone
                canvas.drawLine(cx, 0f, cx, y1 * fillTop, p)
            }
        }
        if (!isLast) {
            val y0 = ny + r + gap
            val h = height.toFloat()
            p.color = theme.hair
            canvas.drawLine(cx, y0, cx, h, p)
            if (done) {
                p.color = theme.lineDone
                canvas.drawLine(cx, y0, cx, y0 + (h - y0) * fillBottom, p)
            }
        }

        // 横線：ノードから文字へ
        val bx0 = 15 * d
        val bx1 = width.toFloat()
        p.color = if (now) theme.accent else theme.hair
        p.strokeWidth = 1 * d
        canvas.drawLine(bx0, ny, bx0 + (bx1 - bx0) * branchGrow, ny, p)

        val state = when {
            done -> NodeState.DONE
            now -> NodeState.NOW
            else -> NodeState.TODO
        }
        Art.node(canvas, theme, state, cx, ny, d, phase, nodeScale, theme.bgBottom, p)
    }
}
