package jp.todayflow

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.View
import android.widget.TextView

/** いまの手順の文字を、小さな4つの角かっこで囲む TextView。かっこは文字の幅だけを囲む。 */
class BracketTextView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : TextView(c, a) {
    var bracketColor = 0
    var bracketLen = 0f      // px（0ならかっこなし）
    var bracketStroke = 0f   // px
    private val bp = Paint()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (bracketLen <= 0f) return
        bp.color = bracketColor
        val w = width.toFloat()
        val h = height.toFloat()
        val s = bracketStroke
        val l = bracketLen
        canvas.drawRect(0f, 0f, l, s, bp); canvas.drawRect(0f, 0f, s, l, bp)
        canvas.drawRect(w - l, 0f, w, s, bp); canvas.drawRect(w - s, 0f, w, l, bp)
        canvas.drawRect(0f, h - s, l, h, bp); canvas.drawRect(0f, h - l, s, h, bp)
        canvas.drawRect(w - l, h - s, w, h, bp); canvas.drawRect(w - s, h - l, w, h, bp)
    }
}

/** 区切り型の進捗バー。いまの手順の区切りが点滅する。 */
class TicksView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var theme: FlowTheme = Themes.ARCTIC
    var done = BooleanArray(0)
    var cur = -1
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var blinkOff = false
    private var anim: ValueAnimator? = null

    fun update(t: FlowTheme, flags: BooleanArray, current: Int) {
        theme = t; done = flags; cur = current
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim = ValueAnimator.ofInt(0, 2).apply {
            duration = 1200
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                val off = (it.animatedValue as Int) == 1
                if (off != blinkOff) { blinkOff = off; invalidate() }
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel(); anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        Art.ticks(canvas, theme, width.toFloat(), height.toFloat(), done, cur, blinkOff, d, p)
    }
}

/** 画面の背景：縦のグラデーションと、テーマによってはうっすらしたドット格子。 */
class BgDrawable(private val t: FlowTheme, private val d: Float) : Drawable() {
    private val p = Paint()
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.dots }

    override fun draw(c: Canvas) {
        val b = bounds
        p.shader = LinearGradient(
            0f, b.top.toFloat(), 0f, b.bottom.toFloat(),
            intArrayOf(t.bgTop, t.bgMid, t.bgBottom), floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(b, p)
        if (t.dots != 0) {
            val step = 14 * d
            val r = 0.9f * d
            var y = b.top + step / 2
            while (y < b.bottom) {
                var x = b.left + step / 2
                while (x < b.right) {
                    c.drawCircle(x, y, r, dot)
                    x += step
                }
                y += step
            }
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
