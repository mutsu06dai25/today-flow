package jp.todayflow

import android.content.Context

/** 骨格（幹・ノード・横線）は共通。見た目の系統だけを2種類に分ける。 */
enum class Look { MINIMAL, TACTICAL }

class FlowTheme(
    val id: String,
    val label: String,
    val look: Look,
    val light: Boolean,
    // 背景（上・中・下のグラデーション）と、うっすらしたドット格子（0ならなし）
    val bgTop: Int, val bgMid: Int, val bgBottom: Int, val dots: Int,
    // 文字と線
    val ink: Int, val muted: Int, val hair: Int, val accent: Int, val tag: Int, val lineDone: Int,
    // 区切り型の進捗バー（TACTICALのみ）
    val tickOn: Int, val tickCur: Int, val tickH: Float,
    // いまの手順を囲む角かっこ（0ならなし）
    val bracketStroke: Float, val bracketLen: Float,
    val titlePrefix: String,
    // 文字サイズ（sp）：通常の手順といまの手順
    val whatSize: Float, val nowSize: Float,
    // ウィジェット
    val widgetBg: Int, val widgetBtn: Int, val widgetBtnText: Int,
)

private fun c(v: Long): Int = v.toInt()

object Themes {
    val MINIMAL = FlowTheme(
        "minimal", "MINIMAL", Look.MINIMAL, true,
        c(0xFFFAF9F6), c(0xFFFAF9F6), c(0xFFFAF9F6), 0,
        c(0xFF141414), c(0xFFA3A19B), c(0xFFDAD8D2), c(0xFF141414), c(0xFFA3A19B), c(0xFF141414),
        c(0xFF141414), c(0xFF141414), 0f,
        0f, 0f,
        "",
        16f, 22f,
        R.drawable.widget_bg_minimal, R.drawable.wbtn_minimal, c(0xFF141414),
    )
    val ARCTIC = FlowTheme(
        "arctic", "ARCTIC", Look.TACTICAL, false,
        c(0xFF13233B), c(0xFF0A1220), c(0xFF07101C), 0,
        c(0xFFEAF4FF), c(0xFF4D6178), c(0xFF1A2940), c(0xFFA8E4FF), c(0xFF7FA6C9), c(0xFFA8E4FF),
        c(0xFFA8E4FF), c(0xFFEAF4FF), 2f,
        1f, 6f,
        "ROUTE / ",
        15.5f, 18.5f,
        R.drawable.widget_bg_arctic, R.drawable.wbtn_arctic, c(0xFFA8E4FF),
    )
    val WHITE_OPS = FlowTheme(
        "whiteops", "WHITE OPS", Look.TACTICAL, true,
        c(0xFFE8E8E3), c(0xFFE8E8E3), c(0xFFE8E8E3), 0x14000000,
        c(0xFF121212), c(0xFF8E8E87), c(0xFFCFCFC8), c(0xFFFF4A1C), c(0xFF121212), c(0xFF121212),
        c(0xFF121212), c(0xFFFF4A1C), 5f,
        1.5f, 7f,
        "● ",
        15.5f, 18.5f,
        R.drawable.widget_bg_whiteops, R.drawable.wbtn_whiteops, c(0xFFFFFFFF),
    )

    val all = listOf(MINIMAL, ARCTIC, WHITE_OPS)
    private const val PREF = "today_flow"

    fun current(ctx: Context): FlowTheme {
        val id = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("theme", MINIMAL.id)
        return all.firstOrNull { it.id == id } ?: MINIMAL
    }

    fun next(ctx: Context): FlowTheme {
        val t = all[(all.indexOf(current(ctx)) + 1) % all.size]
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("theme", t.id).apply()
        return t
    }
}
